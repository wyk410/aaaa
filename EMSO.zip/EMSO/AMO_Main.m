%=======================================================================
% AMO: Animal migration optimization: an optimization algorithm
%      inspired by animal migration behavior
% % Authors: Xiangtao Li, Jie Zhang, Minghao Yin
% Journal: Neural Comput & Applic (2014) 24:1867�C1877
% DOI: 10.1007/s00521-013-1433-8
%=======================================================================
% SourceCode Developed by: Hao Liu 2019-02-26

clc;   %Clear Screen
clear; %Clear workspace
global initial_flag;
initial_flag=0;

cp=parpool('local',4);

PopSize = 50;   % the population size
Runs = 30;      % No. of runs
tol_err = 1e-8; % Absolute Error
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delete Results\AMO\D100\AMO_Results.txt
diary Results\AMO\D100\AMO_Results.txt
funCEC17=[1 3:30];
funUnimodal=1:8;           % Unimodal Functions with Random Dimensionality;
funMultimodal=101:111;  %Multimodal Functions with Random Dimensionality
funCEC05=201:225;          %CEC'05 Functions
funEngProbs=401:408; %Engineering Problems
funUnimodalFixedD=501:509;    % Unimodal Functions with fixed Dimension Dimensionality
funMultimodalFixedD=601:627;  %Multimodal Functions with fixed Dimension Dimensionality
for funNum = funCEC17
    clear -regexp ^AMO;
    [F_Name,Dim,LB,UB,opt_f] = get_fun_info_CEC2017(funNum); % for CEC2017
%     [F_Name,Dim,LB,UB,opt_f] = get_fun_info_usual(funNum); % for ranodm dimensionality and CEC2005
%     [F_Name,Dim,LB,UB,opt_f] = get_fun_info_fixedDandEng(funNum);
    Max_FEs = Dim*1E4;                  %Max. no. of function evaluations
    Max_Iter = ceil(Max_FEs/PopSize);     %T: Max. no. of iteration number
    fprintf('f%d: %s, opt_f=%1.8E, PopSize=%d, Dim=%d, Max_FEs=%d, Max_Ite=%d, Runs=%d\n',funNum, F_Name, opt_f, PopSize, Dim, Max_FEs,Max_Iter, Runs);
    
    AMO_FEs = zeros(1,Runs);
    AMO_f = zeros(1,Runs);
    AMO_TotalTime = zeros(1,Runs);
    AMO_SR = 0;
    AMO_Fbest=[];
    %=====Nr times run independently=====
    parfor r=1:1:Runs
        tic; %Reset the timer
        [AMO_Gbest(r,:), AMO_f(r), AMO_FEs(r), AMO_Fbest(r,:)] = AMO(PopSize,Dim, Max_FEs, Max_Iter, funNum, tol_err, LB, UB, opt_f);
        if AMO_f(r)-opt_f <= tol_err  % Only record "Successful" run
            AMO_SR = AMO_SR + 1;
        end
        AMO_TotalTime(r) = toc;
    end %r
    AMO_SR=100*AMO_SR/Runs;
    %% ===== Save Results =====
    savefile=strcat('Results\AMO\D100\AMO_',num2str(funNum));
    save(savefile,'AMO_Gbest','AMO_f','AMO_Fbest','AMO_SR','AMO_TotalTime','AMO_FEs');
    %% ===== Output Results =====
    fprintf('AMO_Mean = %1.8E,AMO_Std=%1.8E;AMO_Best=%1.8E\n', mean(AMO_f), std(AMO_f), min(AMO_f));
    fprintf('AMO_MeanError = %1.8E,AMO_StdError=%1.8E;AMO_BestError=%1.8E\n', mean(AMO_f-opt_f), std(AMO_f-opt_f), min(AMO_f-opt_f));
    fprintf('AMO_MeanTime = %1.2f, AMO_StdTime=%1.2f; AMO_MeanFEs = %d(%d); SR = %1.2f \n\n', mean(AMO_TotalTime), std(AMO_TotalTime), ceil(mean(AMO_FEs)), ceil(std(AMO_FEs)), AMO_SR);
end
diary off
cp.delete;